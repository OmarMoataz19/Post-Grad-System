﻿namespace UniversityDatabase
{
    public class ActionResult
    {
    }
}